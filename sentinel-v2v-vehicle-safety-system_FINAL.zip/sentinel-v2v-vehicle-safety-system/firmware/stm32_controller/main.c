// STM32 firmware (paste your main.c here)
