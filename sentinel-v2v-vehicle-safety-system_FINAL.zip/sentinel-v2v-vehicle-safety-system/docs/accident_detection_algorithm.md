
Accident Detection Algorithm

1. Read accelerometer data from MPU6050
2. Convert raw data to g-force
3. Compute total acceleration
4. Calculate roll and pitch
5. Trigger accident when:
   acceleration > 2.8g
   OR orientation change > 55°
