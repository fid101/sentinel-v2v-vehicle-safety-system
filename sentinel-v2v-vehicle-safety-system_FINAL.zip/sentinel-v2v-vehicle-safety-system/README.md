
# Sentinel V2V
### Intelligent Vehicle Safety & Anti-Theft Communication System

Sentinel V2V is a prototype embedded automotive safety platform integrating accident detection,
theft protection and vehicle‑to‑vehicle (V2V) communication.

Core technologies used:
- STM32F411 microcontroller
- ESP8266 (IoT + communication controller)
- ESP32 receiver node
- NRF24L01 wireless V2V communication
- MPU6050 accelerometer for crash detection
- SW420 vibration sensor for theft detection
- SSD1306 OLED display
- Blynk IoT mobile interface

⚠ Prototype Note:
This system is currently implemented using development boards.
A fully integrated PCB design is currently in development.

---

## Features

### Accident Detection
Uses MPU6050 accelerometer.

Triggers when:
- Acceleration > 2.8g
- Orientation change > 55°

Broadcasts "ACCIDENT" alert to nearby vehicles.

### Theft Detection
Activated only when vehicle is locked in the Blynk app.
Vibration sensor triggers theft alert and mobile notification.

### Vehicle‑to‑Vehicle Communication
NRF24L01 modules exchange packets between vehicles and estimate proximity:

- FAR
- NEAR
- VERY CLOSE

---

## Prototype Demonstration

### Vehicle Prototype
![Prototype](demo/prototype_vehicle.jpg)

### Distance Detection

Far state:

![Far](demo/oled_far.jpg)

Near state:

![Near](demo/oled_near.jpg)

### Mobile Monitoring Interface

![Blynk](demo/blynk_interface.jpg)

---

## System Architecture

MPU6050 → STM32F411 → ESP8266 → NRF24L01 → ESP32 → OLED Display
ESP8266 also connects to Blynk Cloud for mobile alerts.
